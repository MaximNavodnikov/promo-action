## Шаблон: java11-springboot

Шаблон Java 11 Spring Boot использует maven в качестве системы сборки проекта.

Maven: 3.6.3

Java: OpenJDK 11

Spring Boot: 2.3.1.RELEASE


### Структура проекта

    root
     ├ src                              maven source route
     │ └ main
     │   ├ java                         implement your function here
     │   │ ├ ...
     │   │ ...
     │   └ resources
     │     └ config.yaml               write configuration properties used in scripts in this file
     │                                  config.yaml must not be renamed
     │
     └ pom.xml                          place dependencies of your function here


### Подключение внешних зависимостей

Внешние зависимости могут быть определены в ```./pom.xml``` проекта функции.

    


## Локальная отладка функции
### Prerequisites
На рабочей станции разработчика должны быть установлены:
 - `JDK 11`
 - `Maven 3.5.0+` 

### Локальный запуск приложения 
Если вы используете переменные в файле [config.yaml](./src/main/resources/config.yaml) то для запуска Springboot приложения необходимо определить переменную среды:  
`--spring.config.location=<путь до config.yaml в папке resources>`

Далее можно запустить Main класс [App.java](src/main/java/function/App.java) и вызывать по HTTP (с помощью CURL, Postman и т.д.) необходимые контроллеры.

### Локальное тестирование
Если вы используете переменные в файле [config.yaml](./src/main/resources/config.yaml) то для запуска тестов необходимо указать спрингу на него. Например, как это сделано в [ControllerTest](./src/test/java/function/ControllerTest.java).

Во всем остальном тестирование функции никак не отличается от тестирования любого Springboot приложения.  
Документация по тестированию в Springboot: [https://docs.spring.io](https://docs.spring.io/spring-boot/docs/2.3.1.RELEASE/reference/html/spring-boot-features.html#boot-features-testing)

### Отправка запросов в dataspace
Запрос в dataspace должен быть подписан при помощи APP_KEY и APP_SECRET, которые можно получить из переменных среды, как в примере ниже:
```java
private final String appKey = System.getenv("APP_KEY");
private final String appSecret = System.getenv("APP_SECRET");
private final String dataSpaceUrl = System.getenv("DATASPACE_URL");
```
Подпись запроса осуществляется при помощи библиотеки:
```xml
    <dependency>
            <groupId>sbp.ts.faas</groupId>
            <artifactId>java-sdk-core</artifactId>
            <version>3.1.1</version>
<!--        Раскомментировать в случае локальной отладки-->
<!--            <scope>system</scope>-->
<!--            <systemPath>${project.basedir}/src/libs/java-sdk-core-3.1.1.jar</systemPath>-->
    </dependency>
```
Для отправки запроса в dataspace необходимо в классе [Controller.java](src/main/java/function/Controller.java) добавить следующий код:
```java
//запрос в dataspace
ResponseEntity<String> responseEntity = callDataSpace();
```

Если вы добавили взаимодействие с dataspace, необходимо отредактировать тесты.

Для локальной отладки отправки подписанных запросов в dataspace необходимо:
1. В переменные appKey, appSecret, dataSpaceUrl подставить значения, скопированные из настроек проекта и деталей функции
1. Скачать sdk по ссылке [https://support.hc.sbercloud.ru/devg/apisign/api-sign-sdk-java.html](https://support.hc.sbercloud.ru/devg/apisign/api-sign-sdk-java.html)
1. Разархивировать sdk на своей локальной машине.
1. Создать в проекте директорию [src/libs](src/libs)
1. Скопировать библиотеку libs\java-sdk-core-x.x.x.jar из директории загрузки в директорию [src/libs](src/libs)
1. в файле [pom.xml](pom.xml) раскомментировать строки:
```xml
<scope>system</scope>
<systemPath>${project.basedir}/src/libs/java-sdk-core-3.1.1.jar</systemPath>
```


Во время деплоя функции будут запущены тесты с помощью мавена, если тесты не пройдут — функция не задеплоится.