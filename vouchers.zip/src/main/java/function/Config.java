package function;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.web.client.RestTemplate;
import sbp.sbt.sdk.DataspaceCorePacketClient;
import sbp.sbt.sdk.client.config.DataspaceSdkApiClientConfiguration;
import sbp.sbt.sdk.client.config.apigateway.aksk.AKSKApiGatewayConfiguration;
import sbp.sbt.sdk.search.DataspaceCoreSearchClient;

@Configuration
public class Config {

    @Value("${DATASPACE_URL}")
    private String dataSpaceUrl;
    @Value("${APP_KEY}")
    private String appKey;
    @Value("${APP_SECRET}")
    private String appSecret;

    @Bean
    public RestTemplate restTemplate() {
        return new RestTemplate();
    }

    @Bean
    public DataspaceCoreSearchClient searchClient() {
        return new DataspaceCoreSearchClient(dataSpaceUrl,
                DataspaceSdkApiClientConfiguration.of(builder ->
                        builder
                                .setApiGatewayConfiguration(AKSKApiGatewayConfiguration.of(appKey, appSecret))
                )
        );
    }

    @Bean
    public DataspaceCorePacketClient packetClient() {
        return new DataspaceCorePacketClient(dataSpaceUrl,
                DataspaceSdkApiClientConfiguration.of(builder ->
                        builder
                                .setApiGatewayConfiguration(AKSKApiGatewayConfiguration.of(appKey, appSecret))
                )
        );
    }
}