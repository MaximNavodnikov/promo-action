package function;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

@RestController
public class VouchersController {
    @Autowired
    private VouchersService vouchersService;

    @RequestMapping(value = "/createVoucherSerie")
    public ResponseEntity<String> createVoucherSerie(@RequestParam String voucherSerieCode, @RequestParam Integer vouchersCount) {
        return ResponseEntity.ok()
                .contentType(MediaType.TEXT_PLAIN)
                .body(vouchersService.createVoucherSerie(voucherSerieCode, vouchersCount));
    }

    @RequestMapping(value = "/searchVoucherSerie")
    public ResponseEntity<String> searchVoucherSerie(@RequestParam String voucherSerieCode) {
        return ResponseEntity.ok()
                .contentType(MediaType.TEXT_PLAIN)
                .body(vouchersService.searchVoucherSerie(voucherSerieCode));
    }

    @RequestMapping(value = "/getGiftByPromoCode")
    public ResponseEntity<String> getGiftByPromoCode(@RequestParam String voucherCode, @RequestParam String giftKind) {
        return ResponseEntity.ok()
                .contentType(MediaType.TEXT_PLAIN)
                .body(vouchersService.getGiftByPromoCode(voucherCode, giftKind));
    }
}
