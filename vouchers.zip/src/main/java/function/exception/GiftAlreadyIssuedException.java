package function.exception;

public class GiftAlreadyIssuedException extends RuntimeException {

    public GiftAlreadyIssuedException(String code) {
        super("Gift for the code " + code + " has already been issued");
    }
}
