package function.exception;

public class VoucherNotFoundException extends RuntimeException {

    public VoucherNotFoundException(String code) {
        super("Voucher with code " + code + " not found");
    }
}
