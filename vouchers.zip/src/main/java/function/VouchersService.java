package function;

import com.cloud.apigateway.sdk.utils.Request;
import com.cloud.sdk.auth.signer.Signer;
import com.fasterxml.jackson.databind.JsonNode;
import com.sbt.pprb.ac.graph.collection.GraphCollection;
import function.exception.GiftAlreadyIssuedException;
import function.exception.VoucherNotFoundException;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpMethod;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Component;
import org.springframework.web.client.RestTemplate;
import org.springframework.web.util.UriComponentsBuilder;
import ru.sbt.platformv.ift.dcf600d34_7d21_4d3d_9859_303e826550a6.graph.get.VoucherGet;
import ru.sbt.platformv.ift.dcf600d34_7d21_4d3d_9859_303e826550a6.graph.get.VoucherSerieGet;
import ru.sbt.platformv.ift.dcf600d34_7d21_4d3d_9859_303e826550a6.graph.with.StatusWithLinkable;
import ru.sbt.platformv.ift.dcf600d34_7d21_4d3d_9859_303e826550a6.packet.GiftReference;
import ru.sbt.platformv.ift.dcf600d34_7d21_4d3d_9859_303e826550a6.packet.UpdateVoucherParam;
import ru.sbt.platformv.ift.dcf600d34_7d21_4d3d_9859_303e826550a6.packet.VoucherRef;
import ru.sbt.platformv.ift.dcf600d34_7d21_4d3d_9859_303e826550a6.packet.VoucherSerieRef;
import ru.sbt.platformv.ift.dcf600d34_7d21_4d3d_9859_303e826550a6.packet.packet.Packet;
import ru.sbt.platformv.ift.dcf600d34_7d21_4d3d_9859_303e826550a6.packet.statuses.VoucherVoucherMainStatus;
import sbp.sbt.sdk.DataspaceCorePacketClient;
import sbp.sbt.sdk.exception.SdkJsonRpcClientException;
import sbp.sbt.sdk.exception.detailedexception.ObjectNotFoundException;
import sbp.sbt.sdk.search.DataspaceCoreSearchClient;

import java.util.Collections;
import java.util.HashMap;
import java.util.Map;
import java.util.UUID;

@Component
public class VouchersService {
    private static final Logger LOG = LoggerFactory.getLogger(VouchersService.class);
    private static final String GET_GIFT_ENDPOINT = "/getGift";

    @Autowired
    private RestTemplate restTemplate;
    @Autowired
    private DataspaceCoreSearchClient searchClient;
    @Autowired
    private DataspaceCorePacketClient packetClient;

    @Value("${gifts.url}")
    private String giftsFunctionUrl;
    @Value("${gifts.appKey}")
    private String appKey;
    @Value("${gifts.appSecret}")
    private String appSecret;

    public String getGiftByPromoCode(String code,
                                     String giftKind) {
        try {
            String voucherId = verifyPromoCode(code);

            JsonNode giftResponse = getGift(giftKind, voucherId);

            JsonNode error = giftResponse.get("error");
            if (error != null) {
                return error.textValue();
            }

            updateVoucher(voucherId, giftResponse.get("giftId").textValue());
            return "You have been given a gift from " + giftResponse.get("vendor") + ". Serial number: " + giftResponse.get("serialNumber");

        } catch (Exception e) {
            LOG.error(e.getMessage());
            return e.getMessage();
        }
    }

    public String verifyPromoCode(String code) throws SdkJsonRpcClientException {
        try {
            VoucherGet voucher = searchClient.getVoucher(voucherWith ->
                    voucherWith
                            .withCode()
                            .withStatusForVoucherMain(StatusWithLinkable::withCode)
                            .withGift()

                            .setWhere(where -> where.codeEq(code)));

            if (voucher.getGift().getEntityId() != null ||
                    !voucher.getStatusForVoucherMain().getCode().equals(VoucherVoucherMainStatus.OPEN.getValue())) {
                throw new GiftAlreadyIssuedException(code);
            }

            return voucher.getObjectId();
        } catch (ObjectNotFoundException objectNotFoundException) {
            throw new VoucherNotFoundException(code);
        }
    }

    private JsonNode getGift(String giftKind, String voucherId) throws Exception {
        final String GET_GIFT_URL = giftsFunctionUrl + GET_GIFT_ENDPOINT;

        Request request = new Request();
        request.setMethod("GET");
        request.setBody("");
        request.setKey(appKey);
        request.setSecret(appSecret);
        request.setUrl(GET_GIFT_URL);
        request.addQueryStringParam("voucherId", voucherId);
        request.addQueryStringParam("giftKind", giftKind);
        new Signer().sign(request);

        HttpHeaders requestHeaders = new HttpHeaders();
        request.getHeaders().forEach((k, v) -> requestHeaders.put(k, Collections.singletonList(v)));

        String urlTemplate = UriComponentsBuilder.fromHttpUrl(GET_GIFT_URL)
                .queryParam("voucherId", "{voucherId}")
                .queryParam("giftKind", "{giftKind}")
                .encode()
                .toUriString();

        Map<String, String> params = new HashMap<>();
        params.put("voucherId", voucherId);
        params.put("giftKind", giftKind);

        ResponseEntity<JsonNode> response = restTemplate.exchange(
                urlTemplate, HttpMethod.GET, new HttpEntity<>(requestHeaders), JsonNode.class, params);

        return response.getBody();
    }

    public void updateVoucher(String voucherId,
                              String giftId) throws SdkJsonRpcClientException {
        UpdateVoucherParam updateVoucherParam =
                UpdateVoucherParam.create()
                        .setStatusForVoucherMain(VoucherVoucherMainStatus.ISSUED)
                        .setGift(GiftReference.of(giftId));

        Packet updatePacket = new Packet(voucherId);

        updatePacket.voucher.update(VoucherRef.of(voucherId), updateVoucherParam);

        packetClient.execute(updatePacket);
    }

    public String createVoucherSerie(String code, Integer vouchersCount) {
        Packet packet = new Packet();
        VoucherSerieRef voucherSerie = packet.voucherSerie.create(voucherSerieParam -> voucherSerieParam.setCode(code));

        for (int i = 0; i < vouchersCount; i++) {
            packet.voucher.create(voucherParam ->
                    voucherParam
                            .setCode(code + UUID.randomUUID().toString())
                            .setSerie(voucherSerie)
            );
        }

        try {
            packetClient.execute(packet);
        } catch (SdkJsonRpcClientException e) {
            return e.getMessage();
        }

        return "VoucherSerie with code: " + code + " and " + vouchersCount + " vouchers has been created";
    }

    public String searchVoucherSerie(String code) {

        try {
            GraphCollection<VoucherSerieGet> voucherSerieGets =
                    searchClient.searchVoucherSerie(with -> with.withCode().setWhere(where -> where.codeEq(code)));
            return voucherSerieGets.get(0).getObjectId();
        } catch (SdkJsonRpcClientException e) {
            LOG.error(e.getMessage());
            return e.getMessage();
        }
    }
}
