package function;

import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.node.ArrayNode;
import com.fasterxml.jackson.databind.node.ObjectNode;
import com.sbt.pprb.ac.graph.Selection;
import com.sbt.pprb.ac.graph.SelectionWith;
import com.sbt.pprb.ac.graph.collection.GraphCollection;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import ru.sbt.platformv.ift.dcf600d34_7d21_4d3d_9859_303e826550a6.graph.GiftGraph;
import ru.sbt.platformv.ift.dcf600d34_7d21_4d3d_9859_303e826550a6.grasp.GiftGrasp;
import sbp.sbt.sdk.exception.SdkJsonRpcClientException;
import sbp.sbt.sdk.search.DataspaceCoreSearchClient;

@Component
public class ReportService {
    private static final Logger LOG = LoggerFactory.getLogger(ReportService.class);

    @Autowired
    private DataspaceCoreSearchClient searchClient;
    @Autowired
    private ObjectMapper objectMapper;

    public JsonNode getGiftsReport() {
        ObjectNode response = objectMapper.createObjectNode();
        try {

            SelectionWith<? extends GiftGrasp> selectionWith = GiftGraph.createSelection()
                    .$withGroup("vendor", groupSelector -> groupSelector.none(giftGrasp -> giftGrasp.vendor().name()))
                    .$withGroup("kind", groupSelector -> groupSelector.none(GiftGrasp::kind))
                    .$withGroup("giftsCount", groupSelector -> groupSelector.count(GiftGrasp::kind))

                    .$addGroupBy(groupBy -> groupBy.vendor().name())

                    .$addGroupBy(GiftGrasp::kind);

            GraphCollection<Selection> selections = searchClient.selectionSearch(selectionWith);

            ArrayNode reportRows = objectMapper.createArrayNode();
            selections.forEach(selection -> {
                ObjectNode objectNode = objectMapper.createObjectNode();
                objectNode.put("vendor", selection.$getCalculated("vendor", String.class));
                objectNode.put("kind", selection.$getCalculated("kind", String.class));
                objectNode.put("giftsCount", selection.$getCalculated("giftsCount", Integer.class));
                reportRows.add(objectNode);
            });
            response.set("report", reportRows);

        } catch (SdkJsonRpcClientException e) {
            LOG.error(e.getMessage());
            response.put("error", e.getMessage());
        }

        return response;
    }
}
