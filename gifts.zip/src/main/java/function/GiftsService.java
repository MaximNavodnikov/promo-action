package function;

import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.node.ObjectNode;
import com.sbt.pprb.ac.graph.collection.GraphCollection;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import ru.sbt.platformv.ift.dcf600d34_7d21_4d3d_9859_303e826550a6.graph.with.GiftVendorWithLinkable;
import ru.sbt.platformv.ift.dcf600d34_7d21_4d3d_9859_303e826550a6.jpa.GiftKind;
import ru.sbt.platformv.ift.dcf600d34_7d21_4d3d_9859_303e826550a6.packet.CreateGiftRequestCounterParam;
import ru.sbt.platformv.ift.dcf600d34_7d21_4d3d_9859_303e826550a6.packet.GiftRef;
import ru.sbt.platformv.ift.dcf600d34_7d21_4d3d_9859_303e826550a6.packet.GiftRequestCounterRef;
import ru.sbt.platformv.ift.dcf600d34_7d21_4d3d_9859_303e826550a6.packet.IncGiftRequestCounterParam;
import ru.sbt.platformv.ift.dcf600d34_7d21_4d3d_9859_303e826550a6.packet.KeyGiftRequestCounter;
import ru.sbt.platformv.ift.dcf600d34_7d21_4d3d_9859_303e826550a6.packet.UpdateGiftRequestCounterReq;
import ru.sbt.platformv.ift.dcf600d34_7d21_4d3d_9859_303e826550a6.packet.VoucherReference;
import ru.sbt.platformv.ift.dcf600d34_7d21_4d3d_9859_303e826550a6.packet.packet.Packet;
import ru.sbt.platformv.ift.dcf600d34_7d21_4d3d_9859_303e826550a6.graph.get.GiftGet;
import sbp.sbt.sdk.DataspaceCorePacketClient;
import sbp.sbt.sdk.exception.detailedexception.IdempotencyException;
import sbp.sbt.sdk.search.DataspaceCoreSearchClient;

import java.time.LocalDateTime;

@Component
public class GiftsService {
    private static final Logger LOG = LoggerFactory.getLogger(GiftsService.class);

    @Autowired
    private DataspaceCoreSearchClient searchClient;
    @Autowired
    private DataspaceCorePacketClient packetClient;
    @Autowired
    private ObjectMapper objectMapper;

    public JsonNode getGift(String voucherId, String kind) {
        ObjectNode response = objectMapper.createObjectNode();
        try {
            updateRequestCount(voucherId, kind);
            GraphCollection<GiftGet> gifts = searchClient.searchGift(giftWith ->
                    giftWith
                            .withKind()
                            .withVendor(GiftVendorWithLinkable::withName)
                            .withSerialNumber()
                            .setWhere(where ->
                                    where
                                            .kindEq(GiftKind.valueOf(kind))
                                            .and(where.voucherIsNull().or(where.voucherEq(voucherId)))
                            )
            );

            if (gifts.isEmpty()) {
                LOG.error("Available gift not found");
                response.put("error", "Available gift not found");
                return response;
            }

            GiftGet gift = gifts.get(0);
            String giftId = gift.getObjectId();

            Packet packet = new Packet(giftId);
            packet.gift.update(GiftRef.of(giftId),
                    update -> update
                            .setVoucher(VoucherReference.of(voucherId)));

            packetClient.execute(packet);

            response.put("giftId", giftId);
            response.put("vendor", gift.getVendor().getName());
            response.put("serialNumber", gift.getSerialNumber());

        } catch (IdempotencyException idempotencyException) {
            LOG.error(idempotencyException.getMessage());
            return getGift(voucherId, kind);

        } catch (Exception exception) {
            LOG.error(exception.getMessage());
            response.put("error", exception.getMessage());
        }

        return response;
    }

    private void updateRequestCount(String voucherId, String kind) {
        String idempotencePacketId = voucherId + kind;
        Packet packet = new Packet(idempotencePacketId);

        CreateGiftRequestCounterParam createGiftRequestCounterParam =
                CreateGiftRequestCounterParam.create()
                        .setKind(GiftKind.valueOf(kind))
                        .setLastRequest(LocalDateTime.now());

        GiftRequestCounterRef giftRequestCounter = packet.giftRequestCounter.updateOrCreate(
                createGiftRequestCounterParam, KeyGiftRequestCounter.KIND);

        UpdateGiftRequestCounterReq updateGiftRequestCounterReq =
                UpdateGiftRequestCounterReq.create()
                        .setInc(IncGiftRequestCounterParam.create().setCounter(1));

        packet.giftRequestCounter.update(giftRequestCounter, updateGiftRequestCounterReq);

        packetClient.executeAsync(packet).subscribe();
    }
}
