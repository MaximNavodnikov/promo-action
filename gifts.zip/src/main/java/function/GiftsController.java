package function;

import com.fasterxml.jackson.databind.JsonNode;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

@RestController
public class GiftsController {

    @Autowired
    private GiftsService giftsService;

    @RequestMapping(value = "/getGift")
    public ResponseEntity<JsonNode> getGift(@RequestParam String voucherId, @RequestParam String giftKind) {
        return ResponseEntity.ok()
                .contentType(MediaType.APPLICATION_JSON)
                .body(giftsService.getGift(voucherId, giftKind));
    }
}
